using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SG
{
    public class PlayerStats : MonoBehaviour
    {
        public int healthLevel = 10;
        public int maxHealth;
        public int currentHealth;

        public int staminaLevel = 10;
        public int maxStamina;
        public int currentStamina;

        // �����������ָ����ã�����Inspector��������
        [Header("�����ָ�����")]
        public float staminaRecoverDelay = 1f; // ֹͣ���ĺ��ӳٻָ�ʱ��
        public int staminaRecoverAmount = 2;   // ÿ�λָ�������ֵ
        public float staminaRecoverInterval = 0.2f; // �����ָ����

        HealthBar healthBar;
        StaminaBar staminaBar;
        AnimatorHandler animatorHandler;
        InputHandler inputHandler;
        PlayerManager playerManager;

        [Header("������������")]
        public float damageLockDuration = 0.1f;
        private Coroutine damageLockCoroutine;
        private Coroutine staminaRecoverCoroutine; // �����������ָ�Э��

        private void Awake()
        {
            animatorHandler = GetComponentInChildren<AnimatorHandler>();
            inputHandler = GetComponent<InputHandler>();
            playerManager = GetComponent<PlayerManager>();
            healthBar = FindObjectOfType<HealthBar>();
            staminaBar = FindObjectOfType<StaminaBar>();
        }

        void Start()
        {
            maxHealth = SetMaxHealthFromHealthLevel();
            currentHealth = maxHealth;
            healthBar.SetMaxHealth(maxHealth);

            maxStamina = SetMaxStaminaFromStaminaLevel();
            currentStamina = maxStamina;
            staminaBar.SetMaxStamina(maxStamina);
        }

        private int SetMaxHealthFromHealthLevel()
        {
            maxHealth = healthLevel * 10;
            return maxHealth;
        }

        private int SetMaxStaminaFromStaminaLevel()
        {
            maxStamina = staminaLevel * 10;
            return maxStamina;
        }

        public void TakeDamage(int damage)
        {
            if (playerManager.isDead) return;

            currentHealth = currentHealth - damage;
            healthBar.SetCurrentHealth(currentHealth);
            animatorHandler.PlayTargetAnimation("Damage_01", true);
            StartDamageLock();
            StopStaminaRecover(); // ����������ʱ��ͣ�����ָ�

            if (currentHealth <= 0)
            {
                currentHealth = 0;
                animatorHandler.PlayTargetAnimation("Death_01", true);
                playerManager.isDead = true;
                inputHandler.isInteracting = false;
                inputHandler.rollFlag = false;
                inputHandler.sprintFlag = false;
                inputHandler.isLightAttacking = false;
            }
        }

        public void TakeStaminaDamage(int damage)
        {
            if (currentStamina <= 0 || playerManager.isDead) return;
            currentStamina = Mathf.Max(currentStamina - damage, 0); // ��֤������С��0
            staminaBar.SetCurrentStamina(currentStamina);

            // ��������������ʱ�����ָ��ӳ�
            StopStaminaRecover();
            staminaRecoverCoroutine = StartCoroutine(StartStaminaRecoverAfterDelay());
        }

        // �������ӳٺ�ʼ�����ָ�����
        private IEnumerator StartStaminaRecoverAfterDelay()
        {
            yield return new WaitForSeconds(staminaRecoverDelay);
            // �����ָ���δ��Ѫ��δ������δ����
            while (currentStamina < maxStamina && !playerManager.isDead && !inputHandler.isTakingDamage)
            {
                currentStamina = Mathf.Min(currentStamina + staminaRecoverAmount, maxStamina); // ��֤���������
                staminaBar.SetCurrentStamina(currentStamina);
                yield return new WaitForSeconds(staminaRecoverInterval);
            }
            staminaRecoverCoroutine = null;
        }

        // ������ֹͣ�����ָ�Э��
        public void StopStaminaRecover()
        {
            if (staminaRecoverCoroutine != null)
            {
                StopCoroutine(staminaRecoverCoroutine);
                staminaRecoverCoroutine = null;
            }
        }

        private void StartDamageLock()
        {
            if (damageLockCoroutine != null)
            {
                StopCoroutine(damageLockCoroutine);
            }
            inputHandler.isTakingDamage = true;
            damageLockCoroutine = StartCoroutine(EndDamageLockAfterDelay(damageLockDuration));
        }

        private IEnumerator EndDamageLockAfterDelay(float delay)
        {
            yield return new WaitForSeconds(delay);
            inputHandler.isTakingDamage = false;
            // ������������˺��Զ��ָ�����
            if (currentStamina < maxStamina && !playerManager.isDead)
            {
                staminaRecoverCoroutine = StartCoroutine(StartStaminaRecoverAfterDelay());
            }
            damageLockCoroutine = null;
        }

        // �������������/����ʱֹͣ�ָ�
        private void OnDisable()
        {
            StopStaminaRecover();
        }
    }
}