using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SG
{
    public class PlayerLocomotion : MonoBehaviour
    {
        Transform cameraObject;
        InputHandler inputHandler;
        PlayerManager playerManager;
        public Vector3 moveDirection;

        [HideInInspector]
        public Transform mytransform;
        [HideInInspector]
        public AnimatorHandler animatorHandler;

        public new Rigidbody rigidbody;
        public GameObject normalCamera;

        [Header("Ground & Air Detection Stats")]
        [SerializeField]
        float groundDetectionRayStartPoint = 0.5f;
        [SerializeField]
        float minimumDistanceNeededToBeginFall = 1.1f;
        [SerializeField]
        float groundDirectionRayDistance = 0.3f;
        LayerMask ignoreForGroundCheck;
        public float inAirTimer;

        [Header("Stats")]
        [SerializeField]
        float movementSpeed = 8;
        [SerializeField]
        float sprintSpeed = 12;
        [SerializeField]
        float rotationSpeed = 10;
        [SerializeField]
        float fallingSpeed = 45;

        [Header("�������")]
        [SerializeField] float airMoveSpeedMultiplier = 0.5f;
        [SerializeField] float airRotationSpeedMultiplier = 0.7f;

        [Header("�����Ż�����")]
        [SerializeField] float rollRotationSmoothTime = 0.1f;
        private Vector3 _rollDirSmooth;
        private Vector3 _currentRollDirection;

        [Header("���򷭹�����")]
        [SerializeField] bool useDirectionalRoll = true;
        [SerializeField] float rollDirDeadZone = 0.1f;

        [Header("������������")]
        [SerializeField] float rollImpulseForce = 5f;

        public bool isSprinting;

        [Header("Roll Settings")]
        [SerializeField] float rollStandFrames = 0;
        private int currentStandFrame = 0;

        // ��ض�����������
        [Header("��ض�����������")]
        [SerializeField] private string landAnimName = "Land";
        [SerializeField] private float landAnimEndThreshold = 0.95f;
        private bool isLandAnimPlaying = false;

        [Header("�ṥ��������������")]
        [SerializeField] private string lightAttackAnimPrefix = "LightAttack";
        [SerializeField] private float lightAttackEndThreshold = 0.9f;

        // ��Ծ����
        [Header("��Ծ����")]
        [SerializeField] private float jumpForce = 7f; // ��Ծ���ϵ������ɸ����������
        [SerializeField] private float jumpForwardForce = 2f; // ��ǰ��Ծ�Ķ�����������ѡ����
        // �������������޸���������Ծ������������
        [SerializeField] private string jumpAnimName = "Jump";
        [SerializeField] private float jumpAnimEndThreshold = 0.8f; // ��Ծ�������ŵ�80%�ٽ�������΢��
        private bool isJumpAnimPlaying = false; // ��Ծ�������ű��

        void Start()
        {
            rigidbody = GetComponent<Rigidbody>();
            inputHandler = GetComponent<InputHandler>();
            animatorHandler = GetComponentInChildren<AnimatorHandler>();
            cameraObject = Camera.main.transform;
            mytransform = transform;
            animatorHandler.Initialize();

            playerManager = GetComponent<PlayerManager>();
            playerManager.isGrounded = true;
            ignoreForGroundCheck = ~(1 << 8 | 1 << 11);

            rigidbody.isKinematic = false;
            rigidbody.freezeRotation = true;
            rigidbody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            rigidbody.useGravity = true;

            rigidbody.drag = 2f;
            rigidbody.angularDrag = 2f;
            rigidbody.interpolation = RigidbodyInterpolation.Interpolate;
            normalCamera = Camera.main.gameObject;

            _currentRollDirection = mytransform.forward;
        }

        public void Update()
        {
            // �������������Update�߼�
            if (playerManager.isDead) return;

            float delta = Time.deltaTime;
            isSprinting = inputHandler.sprintFlag;
            inputHandler.TickInput(delta); // ��������ʼ���������⣬������

            // ������/����/��Ծ����״̬
            UpdateLandAnimState();
            UpdateLightAttackAnimState();
            UpdateJumpAnimState(delta); // �������������޸���������Ծ����״̬���

            // �������޸ġ�������Ծ��������������λ�������߼�
            if (isLandAnimPlaying || isJumpAnimPlaying || inputHandler.isLightAttacking || inputHandler.isTakingDamage)
            {
                // ���λ��������룬������������
                inputHandler.moveAmount = 0;
                inputHandler.horizontal = 0;
                inputHandler.vertical = 0;
                inputHandler.sprintFlag = false;
                inputHandler.rollFlag = false;
                return;
            }

            if (!playerManager.isInAir)
            {
                HandleRollingAndSprinting(delta);
            }

            if (useDirectionalRoll)
            {
                UpdateRollDirection(delta);
            }
        }

        private void FixedUpdate()
        {
            // �������������FixedUpdate�߼�
            if (playerManager.isDead)
            {
                rigidbody.velocity = new Vector3(0, rigidbody.velocity.y, 0);
                rigidbody.angularVelocity = Vector3.zero;
                return;
            }

            float fixedDelta = Time.fixedDeltaTime;

            // �������޸ġ�������Ծ��������������λ�������߼�
            if (isLandAnimPlaying || isJumpAnimPlaying || inputHandler.isLightAttacking || inputHandler.isTakingDamage)
            {
                // ��Ծ��������ʱ��������ֱ����ǰ�������ٶȣ��������ֶ�λ��/��ת
                rigidbody.angularVelocity = Vector3.zero;
                animatorHandler.UpdateAnimatorValues(0, 0, false); // ���ö�������
                return;
            }

            HandleMovement(fixedDelta);
            HandleFalling(fixedDelta, moveDirection);

            AnimatorStateInfo stateInfo = animatorHandler.anim.GetCurrentAnimatorStateInfo(0);
            bool isRolling = (stateInfo.IsName("Rolling") || stateInfo.IsName("BackStep") ||
                             stateInfo.IsName("RollLeft") || stateInfo.IsName("RollRight"))
                             && stateInfo.normalizedTime < 0.95f;
            if (isRolling)
            {
                rigidbody.angularVelocity = Vector3.zero;
                rigidbody.position = Vector3.Lerp(rigidbody.position, mytransform.position, 0.5f);
            }
        }

        #region ����״̬��� - ������Ծ�������
        private void UpdateLightAttackAnimState()
        {
            if (playerManager.isDead) return;

            AnimatorStateInfo stateInfo = animatorHandler.anim.GetCurrentAnimatorStateInfo(0);

            // �����Զ���ǰ׺ + WeaponItem��׼����������
            bool isLightAttackAnim = stateInfo.IsName(lightAttackAnimPrefix) ||
                                     stateInfo.IsName(lightAttackAnimPrefix + "1") ||
                                     stateInfo.IsName(lightAttackAnimPrefix + "2") ||
                                     stateInfo.IsName("OH_Light_Attack_1") ||
                                     stateInfo.IsName("OH_Light_Attack_2");

            if (isLightAttackAnim)
            {
                inputHandler.isLightAttacking = stateInfo.normalizedTime < lightAttackEndThreshold;
            }
            else
            {
                if (inputHandler.isLightAttacking)
                {
                    inputHandler.isLightAttacking = false;
                }
            }
        }

        private void UpdateLandAnimState()
        {
            if (playerManager.isDead || !isLandAnimPlaying)
            {
                return;
            }

            AnimatorStateInfo stateInfo = animatorHandler.anim.GetCurrentAnimatorStateInfo(0);
            if (stateInfo.IsName(landAnimName) && stateInfo.normalizedTime >= landAnimEndThreshold)
            {
                isLandAnimPlaying = false;
            }
        }

        // �������������޸���������Ծ����״̬��⣬����ֱ�����ŵ�ָ����ֵ
        private void UpdateJumpAnimState(float delta)
        {
            if (playerManager.isDead || !isJumpAnimPlaying)
            {
                return;
            }

            AnimatorStateInfo stateInfo = animatorHandler.anim.GetCurrentAnimatorStateInfo(0);
            // ��Ծ�������ŵ�ָ����ֵ���ҽ�ɫδ���ʱҲ�������������һֱ������
            if (stateInfo.IsName(jumpAnimName) && stateInfo.normalizedTime >= jumpAnimEndThreshold)
            {
                isJumpAnimPlaying = false;
            }
        }
        #endregion

        #region ��̬���·�������
        private void UpdateRollDirection(float delta)
        {
            Vector3 inputDir = cameraObject.forward * inputHandler.vertical + cameraObject.right * inputHandler.horizontal;
            inputDir.y = 0;

            if (inputDir.magnitude > rollDirDeadZone)
            {
                _currentRollDirection = Vector3.SmoothDamp(_currentRollDirection, inputDir.normalized, ref _rollDirSmooth, rollRotationSmoothTime);
            }
        }
        #endregion

        #region Movement
        Vector3 normalVector = Vector3.up;
        Vector3 targetPosition;

        private void HandleRotation(float delta)
        {
            Vector3 targetDir = Vector3.zero;
            float moveOverride = inputHandler.moveAmount;

            targetDir = cameraObject.forward * inputHandler.vertical;
            targetDir += cameraObject.right * inputHandler.horizontal;

            targetDir.Normalize();
            targetDir.y = 0;

            if (targetDir == Vector3.zero)
                targetDir = mytransform.forward;

            float rs = rotationSpeed;
            if (playerManager.isInAir)
            {
                rs *= airRotationSpeedMultiplier;
            }

            if (isSprinting)
                rs *= 1.5f;

            Quaternion tr = Quaternion.LookRotation(targetDir);
            Quaternion targetRotation = Quaternion.Slerp(mytransform.rotation, tr, rs * delta);
            mytransform.rotation = targetRotation;
        }

        public void HandleMovement(float delta)
        {
            if (inputHandler.moveAmount <= 0)
            {
                rigidbody.velocity = new Vector3(0, rigidbody.velocity.y, 0);
                animatorHandler.UpdateAnimatorValues(0, 0, false);
                return;
            }

            if (inputHandler.isInteracting)
                return;

            moveDirection = cameraObject.forward * inputHandler.vertical;
            moveDirection += cameraObject.right * inputHandler.horizontal;
            moveDirection.Normalize();
            moveDirection.y = 0;

            float speed = isSprinting ? sprintSpeed : movementSpeed;
            if (playerManager.isInAir)
            {
                speed *= airMoveSpeedMultiplier;
            }

            moveDirection *= speed;

            rigidbody.velocity = new Vector3(moveDirection.x, rigidbody.velocity.y, moveDirection.z);
            animatorHandler.UpdateAnimatorValues(inputHandler.moveAmount, 0, isSprinting);

            if (animatorHandler.canRotate)
            {
                HandleRotation(delta);
            }
        }

        public void HandleRollingAndSprinting(float delta)
        {
            AnimatorStateInfo stateInfo = animatorHandler.anim.GetCurrentAnimatorStateInfo(0);
            bool isRolling = (stateInfo.IsName("Rolling") || stateInfo.IsName("BackStep") ||
                             stateInfo.IsName("RollLeft") || stateInfo.IsName("RollRight"))
                             && stateInfo.normalizedTime < 0.9f;

            if (isRolling)
            {
                if (_currentRollDirection.magnitude > 0)
                {
                    Quaternion targetRot = Quaternion.LookRotation(_currentRollDirection);
                    mytransform.rotation = Quaternion.Slerp(mytransform.rotation, targetRot, delta * 20f);
                }
                return;
            }

            if (inputHandler.rollFlag)
            {
                currentStandFrame++;

                if (currentStandFrame >= rollStandFrames)
                {
                    UpdateRollDirection(delta);
                    string rollAnimName = GetDirectionalRollAnimation();
                    animatorHandler.PlayTargetAnimation(rollAnimName, true);

                    if (_currentRollDirection.magnitude > 0)
                    {
                        rigidbody.AddForce(_currentRollDirection * rollImpulseForce, ForceMode.Impulse);
                    }

                    if (_currentRollDirection.magnitude > 0)
                    {
                        Quaternion rollRotation = Quaternion.LookRotation(_currentRollDirection);
                        mytransform.rotation = Quaternion.Slerp(mytransform.rotation, rollRotation, 0.5f);
                    }

                    currentStandFrame = 0;
                    inputHandler.rollFlag = false;
                    inputHandler.sprintFlag = false;
                }
            }
            else
            {
                currentStandFrame = 0;
            }
        }

        #region �������뷽��ѡ�񷭹�����
        private string GetDirectionalRollAnimation()
        {
            if (!useDirectionalRoll)
            {
                return inputHandler.moveAmount > 0 ? "Rolling" : "BackStep";
            }

            float v = inputHandler.vertical;
            float h = inputHandler.horizontal;

            if (v > rollDirDeadZone && Mathf.Abs(h) <= rollDirDeadZone)
                return "Rolling";
            else if (v < -rollDirDeadZone && Mathf.Abs(h) <= rollDirDeadZone)
                return "BackStep";
            else if (h > rollDirDeadZone && Mathf.Abs(v) <= rollDirDeadZone)
                return "RollRight";
            else if (h < -rollDirDeadZone && Mathf.Abs(v) <= rollDirDeadZone)
                return "RollLeft";
            else if (v > 0)
                return "Rolling";
            else
                return "BackStep";
        }
        #endregion

        public void HandleFalling(float delta, Vector3 moveDirection)
        {
            if (playerManager.isDead) return;

            playerManager.isGrounded = false;
            RaycastHit hit;
            Vector3 origin = mytransform.position;
            origin.y += groundDetectionRayStartPoint;

            if (Physics.Raycast(origin, mytransform.forward, out hit, 0.6f))
            {
                moveDirection = Vector3.zero;
            }

            if (playerManager.isInAir)
            {
                rigidbody.AddForce(-Vector3.up * fallingSpeed);
                rigidbody.AddForce(moveDirection * fallingSpeed / 5f);
            }

            Vector3 dir = moveDirection;
            dir.Normalize();
            origin = origin + dir * groundDirectionRayDistance;

            targetPosition = mytransform.position;

            Debug.DrawRay(origin, -Vector3.up * minimumDistanceNeededToBeginFall, Color.red, 0.1f, false);
            if (Physics.Raycast(origin, -Vector3.up, out hit, minimumDistanceNeededToBeginFall, ignoreForGroundCheck))
            {
                normalVector = hit.normal;
                Vector3 tp = hit.point;
                playerManager.isGrounded = true;
                targetPosition.y = tp.y;

                if (playerManager.isInAir)
                {
                    if (inAirTimer > 0.5f)
                    {
                        animatorHandler.PlayTargetAnimation(landAnimName, true);
                        isLandAnimPlaying = true;
                    }
                    else
                    {
                        animatorHandler.PlayTargetAnimation("Empty", false);
                        isLandAnimPlaying = false;
                    }
                    playerManager.isInAir = false;
                    inAirTimer = 0;
                    isJumpAnimPlaying = false; // ��غ�ǿ�ƽ�����Ծ��������
                }
            }
            else
            {
                if (playerManager.isGrounded)
                {
                    playerManager.isGrounded = false;
                }

                if (playerManager.isInAir == false)
                {
                    if (inputHandler.isInteracting == false && !isJumpAnimPlaying) // �ų���Ծ����״̬
                    {
                        animatorHandler.PlayTargetAnimation("Falling", true);
                    }

                    Vector3 vel = rigidbody.velocity;
                    vel.Normalize();
                    rigidbody.velocity = vel * (movementSpeed / 2);
                    playerManager.isInAir = true;
                }
            }

            if (inputHandler.isInteracting || inputHandler.moveAmount > 0)
            {
                mytransform.position = Vector3.Lerp(mytransform.position, targetPosition, Time.deltaTime / 0.1f);
            }
            else
            {
                mytransform.position = targetPosition;
            }

            if (playerManager.isGrounded)
            {
                if (inputHandler.isInteracting || inputHandler.moveAmount > 0)
                {
                    mytransform.position = Vector3.Lerp(mytransform.position, targetPosition, delta);
                }
                else
                {
                    mytransform.position = targetPosition;
                }
            }
        }

        public void HandleJumping()
        {
            if (inputHandler.isInteracting)
                return;
            // ���ڵ�������Ծ����Ϊtrueʱ������Ծ
            if (inputHandler.jump_input && playerManager.isGrounded && !playerManager.isInAir && !isJumpAnimPlaying)
            {
                // ���ô�ֱ�ٶȣ������������ӵ�����Ծ�߶��쳣
                rigidbody.velocity = new Vector3(rigidbody.velocity.x, 0, rigidbody.velocity.z);

                // ʩ�����ϳ�����������Ծ����
                rigidbody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
                // ��ǰ��Ծʱ���Ӷ�����ǰ�������÷�����Ծ����Ȼ
                if (inputHandler.moveAmount > 0)
                {
                    moveDirection = cameraObject.forward * inputHandler.vertical + cameraObject.right * inputHandler.horizontal;
                    moveDirection.y = 0;
                    moveDirection.Normalize();
                    rigidbody.AddForce(moveDirection * jumpForwardForce, ForceMode.Impulse);

                    Quaternion jumprotation = Quaternion.LookRotation(moveDirection);
                    mytransform.rotation = jumprotation;
                }

                // �������������޸���������Ծ�������������״̬
                animatorHandler.PlayTargetAnimation(jumpAnimName, true);
                isJumpAnimPlaying = true; // ������Ծ������ֱ�����ŵ���ֵ/���

                // ���Ϊ����״̬�����������߼�
                playerManager.isInAir = true;
                // �����Ծ���룬��ֹ������Ծ
                inputHandler.jump_input = false;
            }
        }
        #endregion
    }
}